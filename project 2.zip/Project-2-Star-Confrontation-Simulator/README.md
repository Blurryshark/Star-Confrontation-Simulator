# Star-Confrontation-Simulator

This app is for the final project in a class on Software Design. The intent is to create an app that acts as a kind of battle simulator for ships from Star Trek.
