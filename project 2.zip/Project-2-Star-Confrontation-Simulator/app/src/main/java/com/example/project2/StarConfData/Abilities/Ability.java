package com.example.project2.StarConfData.Abilities;

public interface Ability {
}
